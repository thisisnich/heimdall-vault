# FIXED

Drivers/DeviceDrivers/clock.obj: ../Drivers/DeviceDrivers/clock.c
Drivers/DeviceDrivers/clock.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h
Drivers/DeviceDrivers/clock.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdbool.h
Drivers/DeviceDrivers/clock.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/time.h
Drivers/DeviceDrivers/clock.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/linkage.h
Drivers/DeviceDrivers/clock.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/abi_prefix.h
Drivers/DeviceDrivers/clock.obj: G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.3/Drivers/PeripheralDrivers/sysctl.h
Drivers/DeviceDrivers/clock.obj: G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.3/Drivers/CoreDrivers/systick.h
Drivers/DeviceDrivers/clock.obj: G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.3/Drivers/PeripheralDrivers/hibernate.h
Drivers/DeviceDrivers/clock.obj: ../Drivers/DeviceDrivers/clock.h

../Drivers/DeviceDrivers/clock.c: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdbool.h: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/time.h: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/linkage.h: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/abi_prefix.h: 
G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.3/Drivers/PeripheralDrivers/sysctl.h: 
G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.3/Drivers/CoreDrivers/systick.h: 
G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.3/Drivers/PeripheralDrivers/hibernate.h: 
../Drivers/DeviceDrivers/clock.h: 
