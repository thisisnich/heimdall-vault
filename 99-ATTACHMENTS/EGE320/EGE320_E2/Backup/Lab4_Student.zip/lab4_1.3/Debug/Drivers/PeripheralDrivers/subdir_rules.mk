################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
Drivers/PeripheralDrivers/%.obj: ../Drivers/PeripheralDrivers/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: ARM Compiler'
	"C:/ti/ccs1110/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 -me --include_path="D:/lab1/lab4_1.3" --include_path="C:/ti/ccs1110/ccs/tools/compiler/ti-cgt-arm_20.2.5.LTS/include" --include_path="D:/lab1/lab4_1.3/Drivers/CoreDrivers" --include_path="D:/lab1/lab4_1.3/Drivers/DeviceDrivers" --include_path="D:/lab1/lab4_1.3/Drivers/PeripheralDrivers" --include_path="D:/lab1/lab4_1.3/Libraries" --include_path="D:/lab1/lab4_1.3/Libraries/grlib" --include_path="D:/lab1/lab4_1.3/Libraries/grlib/fonts" --define=ccs="ccs" --define=PART_TM4C129ENCPDT -g --gcc --diag_warning=225 --diag_wrap=off --display_error_number --abi=eabi --preproc_with_compile --preproc_dependency="Drivers/PeripheralDrivers/$(basename $(<F)).d_raw" --obj_directory="Drivers/PeripheralDrivers" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


