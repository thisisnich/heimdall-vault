# FIXED

Drivers/DeviceDrivers/buzzer.obj: ../Drivers/DeviceDrivers/buzzer.c
Drivers/DeviceDrivers/buzzer.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h
Drivers/DeviceDrivers/buzzer.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdbool.h
Drivers/DeviceDrivers/buzzer.obj: G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.3/Drivers/PeripheralDrivers/sysctl.h
Drivers/DeviceDrivers/buzzer.obj: G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.3/Drivers/PeripheralDrivers/gpio.h
Drivers/DeviceDrivers/buzzer.obj: G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.3/Drivers/PeripheralDrivers/pwm.h
Drivers/DeviceDrivers/buzzer.obj: ../Drivers/DeviceDrivers/buzzer.h

../Drivers/DeviceDrivers/buzzer.c: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdbool.h: 
G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.3/Drivers/PeripheralDrivers/sysctl.h: 
G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.3/Drivers/PeripheralDrivers/gpio.h: 
G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.3/Drivers/PeripheralDrivers/pwm.h: 
../Drivers/DeviceDrivers/buzzer.h: 
