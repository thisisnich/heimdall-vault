# FIXED

Drivers/PeripheralDrivers/sysctl.obj: ../Drivers/PeripheralDrivers/sysctl.c
Drivers/PeripheralDrivers/sysctl.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdbool.h
Drivers/PeripheralDrivers/sysctl.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h
Drivers/PeripheralDrivers/sysctl.obj: G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.3/Drivers/CoreDrivers/cpu.h
Drivers/PeripheralDrivers/sysctl.obj: G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.3/Drivers/CoreDrivers/interrupt.h
Drivers/PeripheralDrivers/sysctl.obj: ../Drivers/PeripheralDrivers/sysctl.h

../Drivers/PeripheralDrivers/sysctl.c: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdbool.h: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h: 
G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.3/Drivers/CoreDrivers/cpu.h: 
G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.3/Drivers/CoreDrivers/interrupt.h: 
../Drivers/PeripheralDrivers/sysctl.h: 
