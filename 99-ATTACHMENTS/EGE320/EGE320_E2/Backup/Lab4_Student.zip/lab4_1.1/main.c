/**
 * main.c
 */
#include <stdbool.h>
#include <stdint.h>
#include "clock.h"
#include "grlib.h"
#include "st7789_spi.h"                                 //Include the display driver file

extern const uint8_t g_pui8NypLogo[];

tContext sContext = {};

int main(void)
{
    ClockFrequencySet(120000000);                       //Set processor clock to 120MHz
    ST7789PinInit(120000000);                           //Initialize LCD Controller pin
    GrContextInit(&sContext, &g_sST7789);               //Initialize glib Context

    GrImageDraw(&sContext,______________, __, __);      //Printing NYP Logo
    return 0;
}
