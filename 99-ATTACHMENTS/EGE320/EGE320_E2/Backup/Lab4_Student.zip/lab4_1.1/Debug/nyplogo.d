# FIXED

nyplogo.obj: ../nyplogo.c
nyplogo.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h
nyplogo.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdbool.h
nyplogo.obj: G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.1/Libraries/grlib/grlib.h

../nyplogo.c: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdbool.h: 
G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.1/Libraries/grlib/grlib.h: 
