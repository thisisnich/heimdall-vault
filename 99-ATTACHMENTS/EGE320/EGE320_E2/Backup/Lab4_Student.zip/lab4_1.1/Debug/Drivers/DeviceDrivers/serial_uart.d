# FIXED

Drivers/DeviceDrivers/serial_uart.obj: ../Drivers/DeviceDrivers/serial_uart.c
Drivers/DeviceDrivers/serial_uart.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h
Drivers/DeviceDrivers/serial_uart.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdbool.h
Drivers/DeviceDrivers/serial_uart.obj: G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.1/Drivers/PeripheralDrivers/sysctl.h
Drivers/DeviceDrivers/serial_uart.obj: G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.1/Drivers/PeripheralDrivers/gpio.h
Drivers/DeviceDrivers/serial_uart.obj: G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.1/Drivers/PeripheralDrivers/uart.h
Drivers/DeviceDrivers/serial_uart.obj: ../Drivers/DeviceDrivers/serial_uart.h

../Drivers/DeviceDrivers/serial_uart.c: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdbool.h: 
G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.1/Drivers/PeripheralDrivers/sysctl.h: 
G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.1/Drivers/PeripheralDrivers/gpio.h: 
G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.1/Drivers/PeripheralDrivers/uart.h: 
../Drivers/DeviceDrivers/serial_uart.h: 
