# FIXED

Drivers/PeripheralDrivers/watchdog.obj: ../Drivers/PeripheralDrivers/watchdog.c
Drivers/PeripheralDrivers/watchdog.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdbool.h
Drivers/PeripheralDrivers/watchdog.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h
Drivers/PeripheralDrivers/watchdog.obj: G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.1/Drivers/CoreDrivers/interrupt.h
Drivers/PeripheralDrivers/watchdog.obj: ../Drivers/PeripheralDrivers/watchdog.h

../Drivers/PeripheralDrivers/watchdog.c: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdbool.h: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h: 
G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.1/Drivers/CoreDrivers/interrupt.h: 
../Drivers/PeripheralDrivers/watchdog.h: 
