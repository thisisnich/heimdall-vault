# FIXED

main.obj: ../main.c
main.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdbool.h
main.obj: C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h
main.obj: G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.2/Drivers/DeviceDrivers/clock.h
main.obj: G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.2/Libraries/grlib/grlib.h
main.obj: G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.2/Drivers/DeviceDrivers/st7789_spi.h

../main.c: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdbool.h: 
C:/ti/ccsv7/tools/compiler/ti-cgt-arm_16.9.6.LTS/include/stdint.h: 
G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.2/Drivers/DeviceDrivers/clock.h: 
G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.2/Libraries/grlib/grlib.h: 
G:/Workspaces/TI/EG3369_2018/lab4/lab4_1.2/Drivers/DeviceDrivers/st7789_spi.h: 
