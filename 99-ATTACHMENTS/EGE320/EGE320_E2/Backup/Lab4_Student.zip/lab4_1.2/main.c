

/**
 * main.c
 */
#include <stdbool.h>
#include <stdint.h>
#include "clock.h"
#include "grlib.h"
#include "st7789_spi.h"                                 //Include the display driver file

tContext sContext = {};

int main(void)
{
    ClockFrequencySet(120000000);                       //Set processor clock to 120MHz
    ST7789PinInit(120000000);                           //Initialize LCD Controller pin
    GrContextInit(&sContext, &g_sST7789);               //Initialize glib Context

    GrContextFontSet(&sContext, g_psFontCmss48);        //Set the font type to g_psFontCmss48
    GrContextBackgroundSet(&sContext, ClrWhite);        //Set background color to ClrWhite
    GrContextForegroundSet(&sContext, ________);        //Set foreground color to ClrBlack
    GrStringDraw(&sContext, "09:55:34", 8, 50, 60, 0);  //Print the string in HH:MM:SS format
    GrContextFontSet(&sContext, ______________);        //Set the font type to g_psFontCmss28
    GrStringDraw(&sContext, "01:04:18", _, __, __, _);  //Print the string in DD:MM:YY format
    return 0;
}

